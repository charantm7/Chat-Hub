from flask import Flask, render_template, redirect, url_for, request, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'event-secret'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///event.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)

class Event(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150))
    date = db.Column(db.String(50))
    location = db.Column(db.String(100))
    description = db.Column(db.Text)
    creator_id = db.Column(db.Integer, db.ForeignKey('user.id'))

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))



@app.route('/')
def home():
    username = current_user.username if current_user.is_authenticated else None
    return render_template('index.html', username=username)

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = generate_password_hash(request.form['password'])
        if User.query.filter_by(username=username).first():
            flash('Username already exists!')
            return redirect(url_for('signup'))
        new_user = User(username=username, password=password)
        db.session.add(new_user)
        db.session.commit()
        flash('Signup successful. Please log in.')
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(username=request.form['username']).first()
        if user and check_password_hash(user.password, request.form['password']):
            login_user(user)
            return redirect(url_for('view_events'))
        flash('Invalid credentials')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/create-event', methods=['GET', 'POST'])
@login_required
def create_event():
    if request.method == 'POST':
        title = request.form['title']
        date = request.form['date']
        location = request.form['location']
        description = request.form['description']
        event = Event(title=title, date=date, location=location, description=description, creator_id=current_user.id)
        db.session.add(event)
        db.session.commit()
        return redirect(url_for('view_events'))
    return render_template('create_event.html')

@app.route('/events')
def view_events():
    events = Event.query.all()
    return render_template('view_events.html', events=events)

@app.route('/dashboard/admin')
@login_required
def dashboard_admin():
    total_events = Event.query.count()
    user_events = db.session.query(User.username, db.func.count(Event.id))\
        .join(Event, User.id == Event.creator_id)\
        .group_by(User.username).all()
    return render_template('dashboard_admin.html', total=total_events, user_events=user_events)

@app.route('/dashboard/user')
@login_required
def dashboard_user():
    events = Event.query.filter_by(creator_id=current_user.id).all()
    return render_template('dashboard_user.html', events=events)

# --- Init ---
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
